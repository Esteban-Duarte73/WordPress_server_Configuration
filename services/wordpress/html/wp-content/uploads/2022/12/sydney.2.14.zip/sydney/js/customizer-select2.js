jQuery( document ).ready( function() {

    jQuery(document).ready(function() { jQuery("#_customize-input-body_font").select2(); });
    
} ); // jQuery( document ).ready